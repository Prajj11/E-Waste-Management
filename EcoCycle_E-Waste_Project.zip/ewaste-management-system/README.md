# EcoCycle · E-Waste Management System

DBMS Lab Mini Project. Team: Simra Faniband (24CE266), Simran K. Afonso (24CE267), Prajwal P. Naik (25CE90D).

```
ewaste-management-system/
├── frontend/   React + Tailwind UI  (COMPLETE, runs stand-alone with a built-in mock API)
├── backend/    Node + Express REST API  (READY: connects to Oracle)
└── database/   Oracle schema, seed data, report queries
```

## 1. Run the frontend (no backend needed)

```bash
cd frontend
npm install
cp .env.example .env      # VITE_USE_MOCK=true by default
npm run dev               # http://localhost:5173
```

Demo logins (also shown as buttons on the login page):

| Role      | Email               | Password   |
|-----------|---------------------|------------|
| Admin     | admin@ecocycle.in   | admin123   |
| Collector | rahul@ecocycle.in   | collect123 |
| User      | priya@example.com   | user123    |

In mock mode all data lives in the browser's localStorage. Clear site data to reset.

## 2. Set up the Oracle database

```sql
-- as SYSTEM (once)
CREATE USER ewaste IDENTIFIED BY ewaste QUOTA UNLIMITED ON USERS;
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE TRIGGER, CREATE SEQUENCE TO ewaste;
```
```bash
# as ewaste
sqlplus ewaste/ewaste@//localhost:1521/XEPDB1
SQL> @database/01_schema.sql
SQL> @database/02_seed.sql
```

Tables: `app_user`, `ewaste_category`, `collector`, `recycling_facility`, `collection_request`,
`status_history`, `processing_record`. A trigger logs every status change; views feed the reports.
`database/03_report_queries.sql` has ready-made queries for the demo.

## 3. Run the backend

```bash
cd backend
npm install
cp .env.example .env      # set DB_PASSWORD, DB_CONNECT_STRING, JWT_SECRET
npm run seed:users        # turns the seed placeholders into real bcrypt hashes
npm run dev               # http://localhost:5000/api/health
```

## 4. Connect the frontend to the backend

In `frontend/.env` set `VITE_USE_MOCK=false`, then restart `npm run dev`.
Vite proxies `/api` to `http://localhost:5000`.

## REST API (identical in the mock and the real server)

| Method | Path                         | Who             |
|--------|------------------------------|-----------------|
| POST   | /api/auth/login, /register   | public          |
| GET    | /api/categories              | any logged in   |
| POST/PUT/DELETE | /api/categories     | admin           |
| GET    | /api/requests                | user (own), collector (assigned), admin (all) |
| POST   | /api/requests                | user            |
| PATCH  | /api/requests/:id/assign     | admin           |
| PATCH  | /api/requests/:id/status     | collector, admin |
| GET/DELETE | /api/users               | admin           |
| GET    | /api/collectors              | admin           |
| GET/POST/DELETE | /api/facilities     | read: any; write: admin |
| GET/POST/PATCH | /api/processing      | admin           |
| GET    | /api/reports/summary         | admin           |

Request lifecycle: `Pending → Assigned → Collected → Processing → Recycled | Disposed`.

## Status of testing

The frontend files and backend files pass syntax checks. The backend has not been run against a live
Oracle instance yet, so expect to adjust connection details on first run.
